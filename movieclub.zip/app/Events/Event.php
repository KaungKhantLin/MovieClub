<?php

namespace MovieCrazy\Events;

abstract class Event
{
    //
}
